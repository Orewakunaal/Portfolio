/* ===== CONFIG — edit here ===== */
const CONFIG={brand:'NEURALFLOW',tagline:'Less busywork. More breakthrough.',
 email:'hello@example.com',           // replace with your address
 prices:{pro:799,team:1999},annualDiscount:0.2, // 20% off yearly
 signInUrl:'',                        // '' = shows demo notice
 aiEndpoint:'',                       // '' = simulated demo mode. Use YOUR backend proxy; never put secret keys here.
 formEndpoint:''};                    // '' = mailto fallback
/* ===== Simulated demo responses (NOT real AI) ===== */
const DEMO={
 summarize:{ex:['Our team meets weekly but notes get lost and follow-ups slip. We want one shared place for decisions and owners.'],
  out:'SUMMARY (simulated)\n• Notes get lost between meetings\n• Follow-ups lack clear owners\n• One shared decision log is needed\n\nNEXT STEPS\n1. Create a shared decision log\n2. Assign an owner per action\n3. Review every Friday'},
 write:{ex:['Write a professional product-launch announcement for a new workflow tool.'],
  out:'Introducing a clearer way to work (simulated)\n\nToday we are launching our new workflow tool. It helps teams turn ideas into structured plans and keep every step visible.\n\nExplore it today and tell us what you build.'},
 plan:{ex:['Plan a product-launch week for a small team.'],
  out:'LAUNCH WEEK PLAN (simulated)\nMon — Finalize copy [High] · due 10:00\nTue — QA and fixes [High] · due 17:00\nWed — Schedule announcements [Medium]\nThu — Launch [High]\nFri — Review feedback [Medium]'}};
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
let mem={};const store={get:k=>{try{return localStorage.getItem(k)}catch(e){return mem[k]}},set:(k,v)=>{try{localStorage.setItem(k,v)}catch(e){mem[k]=v}}};
/* announcement */
const ann=$('#announce');try{if(sessionStorage.getItem('nf-ann'))ann.hidden=true}catch(e){}
$('#announceClose').onclick=()=>{ann.hidden=true;try{sessionStorage.setItem('nf-ann',1)}catch(e){}};
/* theme */
function setTheme(t){document.documentElement.dataset.theme=t;$('#theme').setAttribute('aria-pressed',t==='light');store.set('nf-theme',t)}
setTheme(document.documentElement.dataset.theme||'dark');$('#theme').onclick=()=>setTheme(document.documentElement.dataset.theme==='dark'?'light':'dark');
/* menu */
const menu=$('#menu'),burger=$('#burger');
function closeMenu(){menu.classList.remove('open');burger.setAttribute('aria-expanded','false')}
burger.onclick=()=>burger.setAttribute('aria-expanded',menu.classList.toggle('open'));
menu.onclick=e=>{if(e.target.tagName==='A')closeMenu()};document.addEventListener('keydown',e=>{if(e.key==='Escape')closeMenu()});
$('#signin').onclick=e=>{e.preventDefault();CONFIG.signInUrl?location.href=CONFIG.signInUrl:alert('Demo notice: this template has no login system. Set CONFIG.signInUrl.')};
$$('.ph').forEach(a=>a.onclick=e=>{e.preventDefault();alert('Placeholder: add your own policy page.')});
$('#year').textContent=new Date().getFullYear();
/* playground */
let mode='summarize';const pr=$('#prompt'),out=$('#output'),err=$('#err');
function setMode(m){mode=m;$$('#pgTabs [role=tab]').forEach(b=>b.setAttribute('aria-selected',b.dataset.m===m));
 $('#examples').innerHTML='';DEMO[m].ex.forEach(t=>{const b=document.createElement('button');b.className='ex';b.textContent='Use example';b.onclick=()=>{pr.value=t;cnt()};$('#examples').append(b)});pr.value=DEMO[m].ex[0];cnt();out.textContent='Your output appears here.'}
function cnt(){$('#count').textContent=pr.value.length+' / 800'}pr.oninput=cnt;
$$('#pgTabs [role=tab]').forEach(b=>{b.onclick=()=>setMode(b.dataset.m);b.onkeydown=e=>{const t=$$('#pgTabs [role=tab]'),i=t.indexOf(b);if(e.key==='ArrowRight'||e.key==='ArrowLeft'){const n=t[(i+(e.key==='ArrowRight'?1:t.length-1))%t.length];n.focus();n.click()}}});
$('#gen').onclick=async()=>{err.textContent='';if(!pr.value.trim()){err.textContent='Enter a prompt first.';pr.focus();return}
 const g=$('#gen');g.disabled=true;g.textContent='Generating…';
 try{if(CONFIG.aiEndpoint){const r=await fetch(CONFIG.aiEndpoint,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({mode,prompt:pr.value.trim()})});if(!r.ok)throw new Error('Server returned '+r.status);const d=await r.json();out.textContent=String(d.output||'')}
 else{await new Promise(r=>setTimeout(r,700));out.textContent=DEMO[mode].out}}
 catch(e){err.textContent='Request failed: '+e.message}
 g.disabled=false;g.textContent='Generate'};
$('#clear').onclick=()=>{pr.value='';cnt();pr.focus()};
$('#copy').onclick=async()=>{const t=out.textContent;try{await navigator.clipboard.writeText(t)}catch(e){const a=document.createElement('textarea');a.value=t;document.body.append(a);a.select();document.execCommand('copy');a.remove()}$('#copy').textContent='Copied';setTimeout(()=>$('#copy').textContent='Copy',1200)};
setMode('summarize');
/* workflow builder */
const TYPES=['Input','AI Processing','Review','Output'],init=()=>[{t:'Input',n:'Collect idea'},{t:'AI Processing',n:'Draft structure'},{t:'Review',n:'Human check'},{t:'Output',n:'Share result'}];
let steps=init();const fl=$('#flow');
function draw(){fl.innerHTML='';steps.forEach((s,i)=>{const li=document.createElement('li');
 li.innerHTML=`<span class="chip">${s.t}</span><input aria-label="Step ${i+1} title" value="${s.n.replace(/"/g,'&quot;')}"><div class="row"><button class="btn ghost" aria-label="Move up">↑</button><button class="btn ghost" aria-label="Move down">↓</button><button class="btn ghost" aria-label="Remove step">✕</button></div>`;
 const[b1,b2,b3]=li.querySelectorAll('button');li.querySelector('input').oninput=e=>s.n=e.target.value;
 b1.onclick=()=>{if(i>0){[steps[i-1],steps[i]]=[steps[i],steps[i-1]];draw()}};b2.onclick=()=>{if(i<steps.length-1){[steps[i+1],steps[i]]=[steps[i],steps[i+1]];draw()}};b3.onclick=()=>{steps.splice(i,1);draw()};fl.append(li)});
 $('#stepCount').textContent=steps.length+' step'+(steps.length===1?'':'s')}
$('#addStep').onclick=()=>{steps.push({t:$('#newType').value,n:'New step'});draw()};$('#resetFlow').onclick=()=>{steps=init();draw()};draw();
/* pricing */
let yearly=false;const fmt=n=>'₹'+Math.round(n).toLocaleString('en-IN');
function price(){$('#disc').textContent='(save '+CONFIG.annualDiscount*100+'%)';$$('.price').forEach(p=>{const m=+p.dataset.m;p.textContent=m?(yearly?fmt(m*12*(1-CONFIG.annualDiscount))+'/yr':fmt(m)+'/mo'):'₹0'})}
$('#bill').onclick=e=>{yearly=!yearly;e.target.setAttribute('aria-checked',yearly);price()};price();
const dlg=$('#dlg');$('#proBtn').onclick=()=>dlg.showModal();$('#dlgClose').onclick=()=>dlg.close();
/* FAQ */
const FAQ=[['Does the demo require an API key?','No. It runs in simulated mode by default.'],['Are the AI outputs real?','No. Outputs are fixed sample responses until you connect your own backend.'],['Can I customize the colors and branding?','Yes. Edit the CSS variables in style.css and CONFIG in script.js.'],['Can I connect my own AI service?','Yes, through your own server endpoint set in CONFIG.aiEndpoint. Keep API keys on the server.'],['Does the template include user authentication?','No. You must add your own.'],['Can I add payment integration?','Yes, but it is not included. Add a payment provider and backend.'],['Does the website work on mobile?','Yes. The layout is responsive.'],['What do I need to deploy it?','Any static host. No build step.']];
$('#faqList').innerHTML=FAQ.map((f,i)=>`<h3><button aria-expanded="false" aria-controls="fa${i}">${f[0]}<span aria-hidden="true">+</span></button></h3><p id="fa${i}" hidden>${f[1]}</p>`).join('');
$$('#faqList button').forEach(b=>b.onclick=()=>{const o=b.getAttribute('aria-expanded')==='true';b.setAttribute('aria-expanded',!o);$('#'+b.getAttribute('aria-controls')).hidden=o;b.lastChild.textContent=o?'+':'−'});
/* contact */
$('#form').onsubmit=async e=>{e.preventDefault();const f=e.target,m=$('#formMsg'),d=Object.fromEntries(new FormData(f));
 if(!d.name.trim()||!/^\S+@\S+\.\S+$/.test(d.email)||!d.message.trim()){m.textContent='Enter your name, a valid email, and a message.';return}
 if(!CONFIG.formEndpoint){location.href=`mailto:${CONFIG.email}?subject=${encodeURIComponent('Project: '+(d.company||d.type))}&body=${encodeURIComponent(`${d.message}\n\n${d.name} (${d.email})`)}`;m.textContent='Your email app should open with a draft. You must send it yourself; nothing was sent yet.';return}
 try{const r=await fetch(CONFIG.formEndpoint,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(d)});if(!r.ok)throw new Error(r.status);m.textContent='Message sent.';f.reset()}catch(x){m.textContent='Sending failed. Please email '+CONFIG.email+' instead.'}};
