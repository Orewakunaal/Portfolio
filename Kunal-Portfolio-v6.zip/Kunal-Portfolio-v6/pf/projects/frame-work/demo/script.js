/* ==========================================================================
   FRAME/WORK — Video Editor Portfolio & Creative Studio Template
   ==========================================================================
   STEP 1 — EDIT THE SETTINGS BELOW. Everything else works automatically.
   ========================================================================== */

const SITE_CONFIG = {
  // Brand name. Use a slash to get the accent-colored slash, e.g. "FRAME/WORK".
  brandName: "FRAME/WORK",

  // Where enquiries go. Replace with your real email address.
  contactEmail: "hello@example.com",

  // Social links. Replace with your own profile URLs.
  // (Defaults point to each platform's home page, not to any real account.)
  social: {
    instagram: "https://www.instagram.com/",
    youtube: "https://www.youtube.com/",
    vimeo: "https://vimeo.com/"
  },

  // Money display
  currency: "₹",          // e.g. "$", "€", "£", "₹"
  locale: "en-IN",        // number formatting, e.g. "en-US", "en-GB", "en-IN"
  prices: {
    short: 1499,          // THE SHORT CUT
    creator: 4999,        // THE CREATOR EDIT
    brand: 9999           // THE BRAND FILM
  },

  // Text shown in the announcement bar at the top of the page
  availabilityText: "AVAILABLE FOR SELECT PROJECTS — 2026",
  // Shorter text shown in the About section
  availabilityShort: "Currently taking on select projects",

  // CONTACT FORM
  // Option A (recommended): paste a form-service endpoint here, e.g. a Formspree URL
  //   "https://formspree.io/f/yourFormId". The form is then sent in the background.
  // Option B: leave as "" — the form prepares an email draft that the visitor sends.
  formEndpoint: "",

  // Your live website address, e.g. "https://yourdomain.com/". Leave "" until deployed.
  // When set, a canonical link tag is added to the page.
  siteUrl: "",

  // Show or hide sections / effects
  showTestimonials: true, // set false to remove the testimonials section completely
  enableCursor: true      // restrained cursor ring on desktop mouse devices only
};

/* ==========================================================================
   Below this line: functionality. Buyers normally don't need to edit this.
   ========================================================================== */
(() => {
  "use strict";

  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
  const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)");

  /* ---------- Apply configuration ---------- */
  function applyConfig() {
    const cfg = SITE_CONFIG;

    // Brand (supports a "/" accent)
    $$("[data-brand]").forEach((el) => {
      el.textContent = "";
      const parts = cfg.brandName.split("/");
      parts.forEach((p, i) => {
        if (i > 0) {
          const s = document.createElement("span");
          s.className = "brand-slash";
          s.textContent = "/";
          el.appendChild(s);
        }
        el.appendChild(document.createTextNode(p));
      });
    });
    $$("[data-brand-text]").forEach((el) => { el.textContent = cfg.brandName; });

    $$('[data-config="availability"]').forEach((el) => { el.textContent = cfg.availabilityText; });
    $$('[data-config="availability-short"]').forEach((el) => { el.textContent = cfg.availabilityShort; });

    $$('[data-config="email-link"]').forEach((el) => {
      el.textContent = cfg.contactEmail;
      el.href = "mailto:" + cfg.contactEmail;
    });
    ["instagram", "youtube", "vimeo"].forEach((key) => {
      $$(`[data-config="${key}"]`).forEach((a) => { if (cfg.social[key]) a.href = cfg.social[key]; });
    });

    // Prices
    let fmt;
    try { fmt = new Intl.NumberFormat(cfg.locale); } catch (e) { fmt = new Intl.NumberFormat("en-US"); }
    $$("[data-price]").forEach((el) => {
      const value = cfg.prices[el.dataset.price];
      if (typeof value === "number") el.textContent = cfg.currency + fmt.format(value);
    });

    // Canonical URL only when a real address is configured
    if (cfg.siteUrl) {
      const link = document.createElement("link");
      link.rel = "canonical";
      link.href = cfg.siteUrl;
      document.head.appendChild(link);
    }

    // Optional sections
    if (!cfg.showTestimonials) {
      const t = $("#testimonials");
      if (t) t.remove();
    }
  }

  /* ---------- Image fallback ---------- */
  function setupImageFallback() {
    document.addEventListener("error", (e) => {
      const t = e.target;
      if (t && t.tagName === "IMG") t.classList.add("img-failed");
    }, true);
    // Catch images that already failed before the listener attached
    $$("img").forEach((img) => { if (img.complete && img.naturalWidth === 0) img.classList.add("img-failed"); });
  }

  /* ---------- Scroll lock ---------- */
  let lockCount = 0;
  function lockScroll() {
    if (lockCount++ === 0) {
      const sbw = window.innerWidth - document.documentElement.clientWidth;
      document.documentElement.classList.add("scroll-locked");
      if (sbw > 0) document.body.style.paddingRight = sbw + "px";
    }
  }
  function unlockScroll() {
    if (lockCount > 0 && --lockCount === 0) {
      document.documentElement.classList.remove("scroll-locked");
      document.body.style.paddingRight = "";
    }
  }

  /* ---------- Header: scroll state + mobile menu ---------- */
  function setupHeader() {
    const header = $(".site-header");
    const toggle = $(".nav-toggle");
    const panel = $("#primary-nav");
    const mq = window.matchMedia("(max-width: 900px)");
    let menuOpen = false;

    const onScroll = () => header.classList.toggle("is-scrolled", window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });

    function setMenu(open, returnFocus) {
      if (open === menuOpen) return;
      menuOpen = open;
      if (open) panel.style.top = header.getBoundingClientRect().bottom + "px";
      toggle.setAttribute("aria-expanded", String(open));
      toggle.setAttribute("aria-label", open ? "Close menu" : "Open menu");
      panel.classList.toggle("is-open", open);
      header.classList.toggle("menu-open", open);
      if (open) lockScroll(); else unlockScroll();
      if (!open && returnFocus) toggle.focus();
    }

    toggle.addEventListener("click", () => setMenu(!menuOpen));
    panel.addEventListener("click", (e) => { if (e.target.closest("a")) setMenu(false); });
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape" && menuOpen) setMenu(false, true);
    });
    // Reset when moving to desktop width
    mq.addEventListener("change", (e) => { if (!e.matches) setMenu(false); });
    // Keep the closed mobile menu out of the tab order & accessibility tree
    const syncInert = () => { if (mq.matches && !menuOpen) panel.setAttribute("aria-hidden", "true"); else panel.removeAttribute("aria-hidden"); };
    syncInert();
    new MutationObserver(syncInert).observe(panel, { attributes: true, attributeFilter: ["class"] });
    mq.addEventListener("change", syncInert);
  }

  /* ---------- Active nav link (current page) ---------- */
  function setupActiveNav() {
    const here = (location.pathname.split("/").pop() || "index.html").toLowerCase();
    $$(".nav-link").forEach((l) => {
      const t = l.getAttribute("href").split(/[?#]/)[0].toLowerCase();
      if (t === here || (here === "case-study.html" && t === "work.html")) { l.classList.add("is-active"); l.setAttribute("aria-current", "page"); }
    });
  }

  /* ---------- Scroll reveal ---------- */
  function setupReveal() {
    const items = $$(".reveal");
    if (!("IntersectionObserver" in window) || reduceMotion.matches) {
      items.forEach((el) => el.classList.add("is-visible"));
      return;
    }
    const io = new IntersectionObserver((entries) => {
      entries.forEach((en) => {
        if (en.isIntersecting) {
          en.target.classList.add("is-visible");
          io.unobserve(en.target);
        }
      });
    }, { rootMargin: "0px 0px -8% 0px", threshold: 0.05 });
    // Stagger siblings slightly
    items.forEach((el) => {
      const siblings = el.parentElement ? Array.from(el.parentElement.children).filter((c) => c.classList.contains("reveal")) : [];
      const idx = siblings.indexOf(el);
      if (idx > 0) el.style.setProperty("--rd", Math.min(idx, 4) * 70 + "ms");
      io.observe(el);
    });
  }

  /* ---------- Portfolio: filtering ---------- */
  function setupPortfolio() {
    const grid = $("#work-grid");
    if (!grid) return;
    const cards = $$(".project-card", grid);
    const buttons = $$(".filter-btn");
    const status = $("#filter-status") || document.createElement("p");

    function applyFilter(filter) {
      let shown = 0;
      grid.classList.toggle("is-filtered", filter !== "all");
      cards.forEach((card) => {
        const match = filter === "all" || card.dataset.categories.split(/\s+/).includes(filter);
        if (match) shown++;
        if (reduceMotion.matches) {
          card.hidden = !match;
          card.classList.remove("is-out");
          return;
        }
        clearTimeout(card._t);
        if (match) {
          card.hidden = false;
          card.classList.add("reveal", "is-visible");
          // next frame so the transition runs
          requestAnimationFrame(() => requestAnimationFrame(() => card.classList.remove("is-out")));
        } else if (!card.hidden) {
          card.classList.add("is-out");
          card._t = setTimeout(() => { card.hidden = true; }, 350);
        }
      });
      buttons.forEach((b) => {
        const on = b.dataset.filter === filter;
        b.classList.toggle("is-active", on);
        b.setAttribute("aria-pressed", String(on));
      });
      const label = (buttons.find((b) => b.dataset.filter === filter) || {}).textContent || "All";
      status.textContent = `Showing ${shown} ${shown === 1 ? "project" : "projects"} in ${label}.`;
    }

    $(".filters").addEventListener("click", (e) => {
      const btn = e.target.closest(".filter-btn");
      if (btn) applyFilter(btn.dataset.filter);
    });

    /* ----- Modal ----- */
    const modal = $("#project-modal");
    const panel = $(".modal-panel", modal);
    const els = {
      img: $("#modal-img"), play: $("#modal-play"), note: $("#modal-note"), visual: $("#modal-visual"),
      cat: $("#modal-cat"), year: $("#modal-year"), title: $("#modal-title"), desc: $("#modal-desc"),
      tools: $("#modal-tools"), count: $("#modal-count"), prev: $("#modal-prev"), next: $("#modal-next")
    };
    let current = null;
    let opener = null;
    let iframe = null;

    const visibleCards = () => cards.filter((c) => !c.hidden && !c.classList.contains("is-out"));

    function isSafeVideoUrl(url) {
      try {
        const u = new URL(url);
        return u.protocol === "https:" && /(^|\.)((youtube(-nocookie)?\.com)|(player\.vimeo\.com))$/.test(u.hostname);
      } catch (e) { return false; }
    }

    function fill(card) {
      current = card;
      const d = card.dataset;
      const img = $("img", card);
      els.cat.textContent = d.category;
      els.year.textContent = d.year;
      els.title.textContent = d.title;
      els.desc.textContent = d.desc;
      els.tools.textContent = "";
      (d.tools || "").split("|").filter(Boolean).forEach((t) => {
        const li = document.createElement("li");
        li.textContent = t.trim();
        els.tools.appendChild(li);
      });

      if (iframe) { iframe.remove(); iframe = null; }
      els.img.classList.remove("img-failed");
      els.img.src = img.getAttribute("src");
      els.img.alt = img.alt;
      if (d.video && isSafeVideoUrl(d.video)) {
        iframe = document.createElement("iframe");
        iframe.src = d.video;
        iframe.title = d.title + " — video";
        iframe.allow = "fullscreen; picture-in-picture; encrypted-media";
        iframe.setAttribute("allowfullscreen", "");
        els.visual.appendChild(iframe);
        els.play.hidden = true;
        if (els.note) els.note.hidden = true;
      } else {
        els.play.hidden = false;
        if (els.note) els.note.hidden = false;
      }

      const list = visibleCards();
      const idx = list.indexOf(card);
      els.count.textContent = `${idx + 1} / ${list.length}`;
      const single = list.length < 2;
      els.prev.disabled = single;
      els.next.disabled = single;
    }

    function open(card, trigger) {
      opener = trigger || document.activeElement;
      fill(card);
      modal.hidden = false;
      lockScroll();
      // allow display change to apply before transition
      requestAnimationFrame(() => {
        modal.classList.add("is-open");
        panel.focus({ preventScroll: true });
        panel.scrollTop = 0;
      });
    }

    function close() {
      if (modal.hidden) return;
      modal.classList.remove("is-open");
      const finish = () => {
        modal.hidden = true;
        if (iframe) { iframe.remove(); iframe = null; }
        unlockScroll();
        if (opener && document.contains(opener) && !opener.closest("[hidden]")) opener.focus();
      };
      if (reduceMotion.matches) finish(); else setTimeout(finish, 300);
    }

    function step(dir) {
      const list = visibleCards();
      if (list.length < 2) return;
      const idx = list.indexOf(current);
      const next = list[(idx + dir + list.length) % list.length];
      opener = $(".project-trigger", next);
      fill(next);
      panel.scrollTop = 0;
    }

    grid.addEventListener("click", (e) => {
      const trigger = e.target.closest(".project-trigger");
      if (!trigger) return;
      open(trigger.closest(".project-card"), trigger);
    });
    modal.addEventListener("click", (e) => { if (e.target.closest("[data-close]")) close(); });
    els.prev.addEventListener("click", () => step(-1));
    els.next.addEventListener("click", () => step(1));

    document.addEventListener("keydown", (e) => {
      if (modal.hidden) return;
      if (e.key === "Escape") { e.preventDefault(); close(); return; }
      if (e.key === "ArrowLeft") { step(-1); return; }
      if (e.key === "ArrowRight") { step(1); return; }
      if (e.key === "Tab") {
        // Focus trap
        const focusables = $$('button:not([disabled]), a[href], iframe, [tabindex]:not([tabindex="-1"])', panel).filter((n) => !n.hidden && n.offsetParent !== null);
        if (!focusables.length) { e.preventDefault(); return; }
        const first = focusables[0];
        const last = focusables[focusables.length - 1];
        if (e.shiftKey && (document.activeElement === first || document.activeElement === panel)) { e.preventDefault(); last.focus(); }
        else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
      }
    });
  }

  /* ---------- FAQ accordion (one open at a time) ---------- */
  function setupFaq() {
    const list = $("#faq-list");
    if (!list) return;
    const buttons = $$(".faq-btn", list);
    function toggle(btn) {
      const willOpen = btn.getAttribute("aria-expanded") !== "true";
      buttons.forEach((b) => b.setAttribute("aria-expanded", "false"));
      btn.setAttribute("aria-expanded", String(willOpen));
    }
    list.addEventListener("click", (e) => {
      const btn = e.target.closest(".faq-btn");
      if (btn) toggle(btn);
    });
    list.addEventListener("keydown", (e) => {
      const btn = e.target.closest(".faq-btn");
      if (!btn) return;
      const i = buttons.indexOf(btn);
      let n = null;
      if (e.key === "ArrowDown") n = buttons[(i + 1) % buttons.length];
      else if (e.key === "ArrowUp") n = buttons[(i - 1 + buttons.length) % buttons.length];
      else if (e.key === "Home") n = buttons[0];
      else if (e.key === "End") n = buttons[buttons.length - 1];
      if (n) { e.preventDefault(); n.focus(); }
    });
  }

  /* ---------- Package links → preselect in form ---------- */
  function setupPackages() {
    const select = $("#f-package");
    const pkg = new URLSearchParams(location.search).get("package");
    if (!select || !pkg) return;
    const opt = Array.from(select.options).find((o) => o.text === pkg);
    if (opt) select.value = opt.value || opt.text;
  }

  /* ---------- Contact form ---------- */
  function setupForm() {
    const form = $("#contact-form");
    if (!form) return;
    const statusBox = $("#form-status");
    const submitBtn = $("#form-submit");
    const hint = $("#form-hint");
    const email = SITE_CONFIG.contactEmail;
    const useEndpoint = Boolean(SITE_CONFIG.formEndpoint);

    // Be honest about what the button does
    if (useEndpoint) {
      submitBtn.firstChild.textContent = "SEND MESSAGE ";
      hint.textContent = "Your message is sent directly. You will see a confirmation here when it has been received.";
    }

    // Deadline cannot be in the past
    const deadline = $("#f-deadline");
    const today = new Date();
    deadline.min = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, "0")}-${String(today.getDate()).padStart(2, "0")}`;

    const rules = {
      name: (v) => (v.trim().length < 2 ? "Please enter your full name." : ""),
      email: (v) => {
        if (!v.trim()) return "Please enter your email address.";
        return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v.trim()) ? "" : "Please enter a valid email address, like name@example.com.";
      },
      type: (v) => (!v ? "Please choose a project type." : ""),
      budget: (v) => (!v ? "Please choose a budget range." : ""),
      details: (v) => (v.trim().length < 10 ? "Please add a few details about your project (at least 10 characters)." : "")
    };

    function validateField(name) {
      const field = form.elements[name];
      const err = $("#e-" + name);
      const msg = rules[name](field.value);
      err.textContent = msg;
      field.setAttribute("aria-invalid", msg ? "true" : "false");
      return !msg;
    }

    Object.keys(rules).forEach((name) => {
      const field = form.elements[name];
      field.addEventListener("blur", () => validateField(name));
      field.addEventListener("input", () => { if (field.getAttribute("aria-invalid") === "true") validateField(name); });
    });

    function show(kind, title, message, extraButton) {
      statusBox.className = "form-status is-visible is-" + kind;
      statusBox.textContent = "";
      const strong = document.createElement("strong");
      strong.textContent = title;
      const p = document.createElement("span");
      p.textContent = message;
      statusBox.append(strong, p);
      if (extraButton) statusBox.appendChild(extraButton);
    }

    function getData() {
      const fd = new FormData(form);
      const get = (k) => String(fd.get(k) || "").trim();
      return {
        name: get("name"), email: get("email"), type: get("type"), package: get("package"),
        budget: get("budget"), deadline: get("deadline"), details: get("details"), honey: get("_gotcha")
      };
    }

    function buildMailto(d) {
      const subject = `Project enquiry: ${d.type} — ${d.name}`;
      const lines = [
        `Name: ${d.name}`,
        `Email: ${d.email}`,
        `Project type: ${d.type}`,
        `Package: ${d.package || "Not sure yet"}`,
        `Budget range: ${d.budget}`,
        `Deadline: ${d.deadline || "Not specified"}`,
        "",
        "Project details:",
        d.details
      ];
      return `mailto:${encodeURIComponent(email).replace(/%40/g, "@")}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(lines.join("\r\n"))}`;
    }

    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      const results = Object.keys(rules).map((n) => [n, validateField(n)]);
      const firstBad = results.find(([, ok]) => !ok);
      if (firstBad) {
        form.elements[firstBad[0]].focus();
        show("error", "Please check the highlighted fields.", "Some required information is missing or invalid.");
        return;
      }
      const d = getData();
      if (d.honey) return; // bot

      if (useEndpoint) {
        submitBtn.disabled = true;
        show("info", "Sending…", "Please wait a moment.");
        try {
          const res = await fetch(SITE_CONFIG.formEndpoint, {
            method: "POST",
            headers: { "Content-Type": "application/json", Accept: "application/json" },
            body: JSON.stringify({
              name: d.name, email: d.email, project_type: d.type, package: d.package,
              budget: d.budget, deadline: d.deadline, message: d.details
            })
          });
          if (!res.ok) throw new Error("HTTP " + res.status);
          show("success", "Message sent.", "Thank you — your enquiry has been received. A reply will come to the email address you provided.");
          form.reset();
          $$("[aria-invalid]", form).forEach((f) => f.removeAttribute("aria-invalid"));
        } catch (err) {
          const copy = document.createElement("button");
          copy.type = "button";
          copy.className = "btn btn-ghost btn-sm";
          copy.textContent = "COPY EMAIL ADDRESS";
          copy.addEventListener("click", () => copyEmail());
          show("error", "Your message could not be sent.", `Please try again, or email ${email} directly.`, copy);
        } finally {
          submitBtn.disabled = false;
        }
        return;
      }

      // Fallback: email draft. Nothing has been sent at this point.
      const href = buildMailto(d);
      const again = document.createElement("a");
      again.className = "btn btn-ghost btn-sm";
      again.href = href;
      again.textContent = "OPEN EMAIL DRAFT AGAIN";
      show("info", "Your email draft is ready — it has not been sent yet.",
        `Your email app should open with the message filled in. Press Send there to deliver it. If nothing opens, copy ${email} and email it directly.`, again);
      statusBox.focus();
      window.location.href = href;
    });
  }

  /* ---------- Copy email ---------- */
  function copyEmail() {
    const email = SITE_CONFIG.contactEmail;
    const live = $("#copy-status");
    const btn = $("#copy-email");
    const done = (ok) => {
      const msg = ok ? "Email address copied." : "Copy failed — please select the address and copy it manually.";
      live.textContent = msg;
      if (btn) {
        const old = btn.dataset.label || btn.textContent;
        btn.dataset.label = old;
        btn.textContent = ok ? "COPIED ✓" : "COPY FAILED";
        setTimeout(() => { btn.textContent = old; }, 2000);
      }
    };
    const legacy = () => {
      const ta = document.createElement("textarea");
      ta.value = email;
      ta.setAttribute("readonly", "");
      ta.style.cssText = "position:fixed;top:0;left:0;opacity:0;";
      document.body.appendChild(ta);
      ta.select();
      let ok = false;
      try { ok = document.execCommand("copy"); } catch (e) { ok = false; }
      ta.remove();
      done(ok);
    };
    if (navigator.clipboard && window.isSecureContext) {
      navigator.clipboard.writeText(email).then(() => done(true), legacy);
    } else {
      legacy();
    }
  }

  /* ---------- Footer: year + back to top ---------- */
  function setupFooter() {
    const y = $("#year");
    if (y) y.textContent = String(new Date().getFullYear());
    const topBtn = $("#to-top");
    if (topBtn) topBtn.addEventListener("click", () => {
      window.scrollTo({ top: 0, behavior: reduceMotion.matches ? "auto" : "smooth" });
      const brand = $(".site-header .brand");
      if (brand) brand.focus({ preventScroll: true });
    });
  }

  /* ---------- Cursor ring (desktop, mouse only) ---------- */
  function setupCursor() {
    if (!SITE_CONFIG.enableCursor) return;
    const ok = window.matchMedia("(hover: hover) and (pointer: fine)").matches && !reduceMotion.matches;
    const el = $("#cursor");
    if (!ok || !el) return;
    el.classList.add("is-on");
    let x = 0, y = 0, tx = 0, ty = 0, raf = null;
    const loop = () => {
      x += (tx - x) * 0.2;
      y += (ty - y) * 0.2;
      el.style.transform = `translate3d(${x}px, ${y}px, 0)`;
      raf = Math.abs(tx - x) + Math.abs(ty - y) > 0.5 ? requestAnimationFrame(loop) : null;
    };
    window.addEventListener("pointermove", (e) => {
      if (e.pointerType !== "mouse") return;
      tx = e.clientX; ty = e.clientY;
      el.classList.add("is-visible");
      if (!raf) raf = requestAnimationFrame(loop);
    }, { passive: true });
    document.addEventListener("pointerover", (e) => {
      el.classList.toggle("is-hover", Boolean(e.target.closest("a, button, .project-card, select, input, textarea")));
    });
    document.documentElement.addEventListener("pointerleave", () => el.classList.remove("is-visible"));
  }

  /* ---------- Init ---------- */
  function init() {
    applyConfig();
    setupImageFallback();
    setupHeader();
    setupActiveNav();
    setupReveal();
    setupPortfolio();
    setupFaq();
    setupPackages();
    setupForm();
    const copyBtn = $("#copy-email");
    if (copyBtn) copyBtn.addEventListener("click", copyEmail);
    setupFooter();
    setupCursor();
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
  else init();
})();
